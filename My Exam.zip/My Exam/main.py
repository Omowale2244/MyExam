from fastapi import FastAPI
from routers.patient import patient_router
from routers.doctor import doctor_router
from routers.appointment import Appointment_router


app = FastAPI ()

app.include_router(patient_router, prefix='/patients',tags=['PATIENT'])
app.include_router(doctor_router, prefix='/doctors', tags=['DOCTOR'])
app.include_router(Appointment_router, prefix='/appointments', tags=['APPOINTMENT'] )


@app.get("/")
def index():
    return {"welcome to our medical app"}