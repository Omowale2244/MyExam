from fastapi import APIRouter, HTTPException
from schema.appointment import Appointments, AppointmentCreate

Appointment_router = APIRouter()

@Appointment_router.get('/', status_code=200)
def list_appointment():
    return {'massage': 'success', 'data': Appointments}

@Appointment_router.post('/',status_code = 201)
def create_appointment(payload: AppointmentCreate):
    Appointments_id = len(Appointments) + 1
    new_appointment = Appointments(id=Appointments_id, patient=payload.patient, doctor=payload.doctor, date=payload.date)
    Appointments.append(new_appointment)
    return{'massage': 'Patient created successfully','data':new_appointment}
