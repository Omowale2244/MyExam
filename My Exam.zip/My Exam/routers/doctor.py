from fastapi import APIRouter, HTTPException
from schema.doctor import Doctor, DoctorCreate, doctors

doctor_router = APIRouter()

@doctor_router.post('/',status_code = 201)
def create_doctor(payload: DoctorCreate):
    doctor_id = len(doctors) + 1
    new_doctor = Doctor(id=doctor_id, 
                        name=payload.name, 
                        specialization=payload.specialization, 
                        phone=payload.phone,
                        
                        is_available=payload.is_available
                    )
    doctors.append(new_doctor)
    return{'massage': 'Patient created successfully','data':new_doctor}

@doctor_router.get('/', status_code=200)
def list_doctors():
    return {'massage': 'success', 'data': Doctor}

@doctor_router.put('/{doctor_id}', status_code=200)
def edit_doctor(doctor_id: int, payload: DoctorCreate):
    cur_doctor = None

    for doctor in Doctor:
        if doctor.id ==doctor_id:
            cur_doctor = doctor
            break
        if not cur_doctor:
            raise HTTPException(status=404, detail="Doctor not found in our record")
        cur_doctor.name = payload.name
        cur_doctor.specialization = payload.specialization
        cur_doctor.phone = payload.phone
        cur_doctor.is_available = payload.is_available
        return{'massage': 'Doctor edited successfully','data':cur_doctor}
    
@doctor_router.delete('/{doctor_id}', status_code=200)
def delete_doctor(doctor_id: int ):
    Doctor = doctor_id
    return{'massage': 'Doctor deleted successfully','data':Doctor}