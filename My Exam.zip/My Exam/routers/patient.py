from fastapi import APIRouter, HTTPException

from schema.patient import Patient, PatientCreate, Patients

patient_router = APIRouter()

@patient_router.post('/',status_code = 201)
def create_patient(payload: PatientCreate):
    patient_id = len(Patients) + 1
    new_patient = Patient(id=patient_id, name=payload.name, age=payload.age, sex=payload.sex, weight=payload.weight, height=payload.height,phone=payload.phone)
    Patients.append(new_patient)
    return{'massage': 'Patient created successfully','data':new_patient}

@patient_router.get('/', status_code=200)
def list_patients():
    return {'massage': 'success', 'data': Patients}


@patient_router.put('/{patient_id}', status_code=200)
def edit_patient(patient_id: int, payload: PatientCreate):
    cur_patient = None

    for patient in Patients:
        if patient.id ==patient_id:
            cur_patient = patient
            break
        if not cur_patient:
            raise HTTPException(status=404, detail="Patient not found in our record")
        cur_patient.name = payload.name
        cur_patient.age = payload.age
        cur_patient.sex = payload.sex
        cur_patient.weight = payload.weight
        cur_patient.hight = payload.height
        cur_patient.phone = payload.phone
        return{'massage': 'Patient edited successfully','data':cur_patient}
    
@patient_router.delete("/{patient_id}", status_code=200)
def delete_patient(patient_id: int ):
    Patient = patient_id
    return{'massage': 'Patient deleted successfully','data':Patient}




