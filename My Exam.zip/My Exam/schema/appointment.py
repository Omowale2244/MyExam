from pydantic import BaseModel


class Appointment(BaseModel):
    id: int
    patient: str
    doctor: str
    date: str

class AppointmentCreate(BaseModel):
    patient: str
    doctor: str
    date: str

Appointments = [
        Appointment(id=1, patient ="Patient", doctor="doctors", date= "datetime"),
        Appointment(id=2, patient ="Patient", doctor="doctors", date= "datetime" ),
    ]


