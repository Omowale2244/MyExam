from pydantic import BaseModel

class Doctor(BaseModel):
    id: int
    name: str
    specialization: str
    phone: str
    is_available: str

class DoctorCreate(BaseModel):
    name: str
    specialization: str
    phone: str
    is_available: str

doctors = [
    Doctor(id = 1, name= "Dr Albert", specialization = "Gynacologist", phone = "08038945644", is_available= "True"),
    Doctor(id = 2, name= "Dr Victoria", specialization = "Diagnosis", phone = "08039085644", is_available= "True"),
    Doctor(id = 3, name= "Dr sylvester", specialization = "kidney transplant", phone = "08038945644", is_available= "True")
]



