from pydantic import BaseModel

class Patient(BaseModel):
    id: int
    name: str
    age: int
    sex: str
    weight: float
    height: float
    phone: str

class PatientCreate(BaseModel):
    name: str
    age: int
    sex: str
    weight: float
    height: float
    phone: str

Patients = [
    Patient(id = 1, name = "Adeniyi Jones", age = 40, sex = "Male", weight = 40.5, height= 7.5, phone = "08038366459"),
    Patient(id = 2, name = "Albert Tina", age = 35, sex = "Female", weight = 65.5, height= 6.5, phone = "07020300345")
]